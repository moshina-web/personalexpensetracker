const API_URL = '/api/expenses';
let expenses = [];

document.addEventListener('DOMContentLoaded', fetchExpenses);

async function fetchExpenses() {
  try {
    const res = await fetch(API_URL);
    expenses = await res.json();
    renderExpenses(expenses);
  } catch (err) {
    console.error('Error fetching data:', err);
  }
}

function renderExpenses(data) {
  const list = document.getElementById('expense-list');
  list.innerHTML = '';
  let total = 0;

  data.forEach(item => {
    total += parseFloat(item.amount);
    list.innerHTML += `
      <tr>
        <td>${item.title}</td>
        <td>₹${item.amount}</td>
        <td>${item.category}</td>
        <td>${item.date ? item.date.split('T')[0] : ''}</td>
        <td>
          <button class="btn-edit" onclick="editExpense(${item.id})">Edit</button>
          <button class="btn-delete" onclick="deleteExpense(${item.id})">Delete</button>
        </td>
      </tr>
    `;
  });

  document.getElementById('total-amount').innerText = total;
}

document.getElementById('expense-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('expense-id').value;
  const title = document.getElementById('title').value;
  const amount = document.getElementById('amount').value;
  const category = document.getElementById('category').value;
  const date = document.getElementById('date').value;

  const expenseData = { title, amount, category, date };

  if (id) {
    await fetch(`${API_URL}/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(expenseData)
    });
  } else {
    await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(expenseData)
    });
  }

  document.getElementById('expense-form').reset();
  document.getElementById('expense-id').value = '';
  document.getElementById('submit-btn').innerText = 'Add Expense';
  fetchExpenses();
});

function editExpense(id) {
  const item = expenses.find(e => e.id === id);
  if (item) {
    document.getElementById('expense-id').value = item.id;
    document.getElementById('title').value = item.title;
    document.getElementById('amount').value = item.amount;
    document.getElementById('category').value = item.category;
    document.getElementById('date').value = item.date ? item.date.split('T')[0] : '';
    document.getElementById('submit-btn').innerText = 'Update Expense';
  }
}

async function deleteExpense(id) {
  if (confirm('Delete this expense?')) {
    await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
    fetchExpenses();
  }
}

function filterExpenses() {
  const search = document.getElementById('search').value.toLowerCase();
  const category = document.getElementById('filter-category').value;

  const filtered = expenses.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(search);
    const matchesCategory = category === 'ALL' || item.category === category;
    return matchesSearch && matchesCategory;
  });

  renderExpenses(filtered);
}