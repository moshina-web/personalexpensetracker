const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Serve static frontend files
const frontendDir = path.resolve(__dirname, '../Frontend');
app.use(express.static(frontendDir));

// Connect SQLite Database
const db = new sqlite3.Database('./expense_db.sqlite', (err) => {
  if (err) {
    console.error('Database connection failed:', err.message);
  } else {
    console.log('Connected to SQLite Database.');
  }
});

// Create Table and Insert Initial Data
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      amount REAL NOT NULL,
      category TEXT NOT NULL,
      date TEXT NOT NULL
    )
  `);

  db.get("SELECT COUNT(*) AS count FROM expenses", (err, row) => {
    if (row && row.count === 0) {
      const stmt = db.prepare("INSERT INTO expenses (title, amount, category, date) VALUES (?, ?, ?, ?)");
      const today = new Date().toISOString().split('T')[0];
      stmt.run("Food", 150, "Food", today);
      stmt.run("Transport", 80, "Transport", today);
      stmt.run("Shopping", 500, "Shopping", today);
      stmt.run("Education", 300, "Education", today);
      stmt.run("Entertainment", 200, "Entertainment", today);
      stmt.finalize();
    }
  });
});

// Import API Routes
const expenseRoutes = require('./routes/expenseRoutes')(db);
app.use('/api/expenses', expenseRoutes);

// Root route - Express v5 compatible (No asterisk wildcard)
app.get('/', (req, res) => {
  res.sendFile(path.join(frontendDir, 'index.html'));
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});