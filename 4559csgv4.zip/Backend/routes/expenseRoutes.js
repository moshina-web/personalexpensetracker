const express = require('express');
const router = express.Router();

module.exports = (db) => {
  // Get all expenses
  router.get('/', (req, res) => {
    db.all('SELECT * FROM expenses ORDER BY id DESC', [], (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    });
  });

  // Add expense
  router.post('/', (req, res) => {
    const { title, amount, category, date } = req.body;
    const query = 'INSERT INTO expenses (title, amount, category, date) VALUES (?, ?, ?, ?)';
    db.run(query, [title, amount, category, date], function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID, title, amount, category, date });
    });
  });

  // Edit / Update expense
  router.put('/:id', (req, res) => {
    const { title, amount, category, date } = req.body;
    const query = 'UPDATE expenses SET title=?, amount=?, category=?, date=? WHERE id=?';
    db.run(query, [title, amount, category, date, req.params.id], function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Expense updated successfully' });
    });
  });

  // Delete expense
  router.delete('/:id', (req, res) => {
    db.run('DELETE FROM expenses WHERE id=?', [req.params.id], function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Expense deleted successfully' });
    });
  });

  return router;
};