CREATE DATABASE IF NOT EXISTS expense_db;
USE expense_db;

CREATE TABLE IF NOT EXISTS expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    category VARCHAR(100) NOT NULL,
    date DATE NOT NULL
);

INSERT INTO expenses (title, amount, category, date) VALUES
('Food', 150.00, 'Food', CURDATE()),
('Transport', 80.00, 'Transport', CURDATE()),
('Shopping', 500.00, 'Shopping', CURDATE()),
('Education', 300.00, 'Education', CURDATE()),
('Entertainment', 200.00, 'Entertainment', CURDATE());